#
# This is a Shiny web application. You can run the application by clicking
# the 'Run App' button above.
#
# Find out more about building applications with Shiny here:
#
#    http://shiny.rstudio.com/
#

library(shiny)
library(tidyverse)
library(DT)
library(shinydashboard)
library(shinyWidgets)
library(dplyr)


consump_data <- read_csv("Raw Consumption - EJ.csv")

# Define UI for application that draws a histogram
ui <- fluidPage(
    
    useShinydashboard(),

    # Application title
    titlePanel("Consumption Key Stats"),

    # Sidebar with a slider input for number of bins 
    sidebarLayout(
        sidebarPanel(
            sliderInput("MaxYear",
                        "Year",
                        min = 2000,
                        max = 2019,
                        value = 2019,
                        sep = "" )
            
            
        ),

        # Show a plot of the generated distribution
        mainPanel(
           #fluidRow(box(width = 6, title = "test",status = "primary"))
            useShinydashboard(),
            fluidRow(
                valueBoxOutput('totalEnergy'),
                valueBoxOutput('cleanProp'),
            )
        )
    )
)

# Define server logic required to draw a histogram
server <- function(input, output) {

    consumpToDate <- consump_data %>%
        filter(Year <= 2019)
    
    cleanConsumpToDate <- consump_data %>%
        filter(Year <= 2019 & Classification == "Renewable")
    
    #TradConsumpToDate <- consump_data %>%
        #filter(Year <= 2019 & Classification == "Traditional")
    
    output$totalEnergy <- renderInfoBox({
        consumpToDate <- subset(consump_data, Year <= input$MaxYear)
        valueBox(paste0(ceiling(sum(consumpToDate$Consumption)), " EJ"), "Global Energy Consumption",
                                         color = "yellow", icon = icon("bolt")
        )
    })
    
    output$cleanProp <- renderInfoBox({
        consumpToDate <- subset(consump_data, Year <= input$MaxYear)
        cleanConsumpToDate <- subset(cleanConsumpToDate, Year <= input$MaxYear)
        valueBox(paste0(round((sum(cleanConsumpToDate$Consumption)/sum(consumpToDate$Consumption)*100),digits = 2)," %"), 
                 "from renewable sources",
        color = "green", icon = icon("leaf")
        
    )
        
    })
    

}

# Run the application 
shinyApp(ui = ui, server = server)
