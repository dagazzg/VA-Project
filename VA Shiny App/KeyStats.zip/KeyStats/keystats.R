#
# This is a Shiny web application. You can run the application by clicking
# the 'Run App' button above.
#
# Find out more about building applications with Shiny here:
#
#    http://shiny.rstudio.com/
#

library(shiny)
library(tidyverse)
library(DT)
library(shinydashboard)
library(shinyWidgets)
library(dplyr)


consump_data <- read_csv("Raw Consumption - EJ.csv")

# Define UI for application that draws a histogram
ui <- fluidPage(
    
    useShinydashboard(),

    # Application title
    titlePanel("Consumption Key Stats"),

    # Sidebar with a slider input for number of bins 
    sidebarLayout(
        sidebarPanel(
            sliderInput("MaxYear",
                        "Year",
                        min = 2000,
                        max = 2019,
                        value = 2019,
                        sep = "" )
            
            
        ),

        # Show a plot of the generated distribution
        mainPanel(
            useShinydashboard(),
            fluidRow(
                valueBoxOutput('totalEnergy', width = 3),
                valueBoxOutput('tradProp', width = 3),
                valueBoxOutput('cleanProp', width = 3),
                valueBoxOutput('nuclProp', width = 3)
            )
        )
    )
)

# Define server logic required to draw a histogram
server <- function(input, output) {

    consumpToDate <- consump_data %>%
        filter(Year <= 2019)
    
    cleanConsumpToDate <- consump_data %>%
        filter(Year <= 2019 & Classification == "Renewable")
    
    TradConsumpToDate <- consump_data %>%
        filter(Year <= 2019 & Classification == "Traditional")
    
    NuclConsumpToDate <- consump_data %>%
        filter(Year <= 2019 & Classification == "Nuclear")
    
    output$totalEnergy <- renderInfoBox({
        consumpToDate <- subset(consump_data, Year == input$MaxYear)
        valueBox(paste0(ceiling(sum(consumpToDate$Consumption)), " EJ"), "Global Consumption",
                                         color = "yellow", icon = icon("bolt"), width = 3
        )
    })
    
    output$cleanProp <- renderInfoBox({
        consumpToDate <- subset(consump_data, Year == input$MaxYear)
        cleanConsumpToDate <- subset(cleanConsumpToDate, Year == input$MaxYear)
        valueBox(paste0(round((sum(cleanConsumpToDate$Consumption)/sum(consumpToDate$Consumption)*100),digits = 1),"%"), 
                 "from renewable sources",
                  color = "green", icon = icon("leaf"), width = 2
                  
        
    )
        
    })
    
    output$tradProp <- renderInfoBox({
        consumpToDate <- subset(consump_data, Year == input$MaxYear)
        TradConsumpToDate <- subset(TradConsumpToDate, Year == input$MaxYear)
        valueBox(paste0(round((sum(TradConsumpToDate$Consumption)/sum(consumpToDate$Consumption)*100),digits = 1),"%"), 
                 "from fossil fuels",
                 color = "red", icon = icon("gas-pump"), width = 2
                 
                 
        )
        
    })
    
    output$nuclProp <- renderInfoBox({
        consumpToDate <- subset(consump_data, Year == input$MaxYear)
        NuclConsumpToDate <- subset(NuclConsumpToDate, Year == input$MaxYear)
        valueBox(paste0(round((sum(NuclConsumpToDate$Consumption)/sum(consumpToDate$Consumption)*100),digits = 1),"%"), 
                 "from nuclear",
                 color = "lime", icon = icon("radiation-alt"),
                 
        )
        
    })

}

# Run the application 
shinyApp(ui = ui, server = server)
